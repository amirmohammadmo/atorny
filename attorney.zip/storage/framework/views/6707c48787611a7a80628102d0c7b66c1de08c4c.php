<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme" data-bg-class="bg-menu-theme">
    <div class="app-brand demo">






































        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-xl-none">
            <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
    </div>


    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1 ps ps--active-y">
        <!-- Dashboard -->
        <li class="menu-item">
            <a href="#" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">داشبورد</div>
            </a>
        </li>

        <!-- Layouts -->
        <li class="menu-item open" style="">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">مدارک</div>
            </a>

            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="<?php echo e(Route('admin.Document_show')); ?>" class="menu-link">
                        <div data-i18n="Without menu">ارسال مدارک</div>
                    </a>
                </li>
                <li class="menu-item">
                    <a href="<?php echo e(Route('admin.Documents_received.show')); ?>" class="menu-link">
                        <div data-i18n="Without navbar">مدارک دریافتی </div>
                    </a>
                </li>
        </li>
        <li class="menu-item">
            <a href="<?php echo e(Route('admin.Documents_users')); ?>" class="menu-link">
                <div data-i18n="Without navbar">مشاهده ی پرونده ها </div>
            </a>
        </li>



            </ul>
        </li>
        <li class="menu-item open" style="">
            <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">مدیریت کاربران</div>
            </a>
            <ul class="menu-sub">
                <li class="menu-item">
                    <a href="#" class="menu-link">
                        <div data-i18n="Without menu">مشاهده ی کاربران</div>
                    </a>
                </li>




            </ul>





            </ul>

        </li>




        <!-- Components -->
        <!-- Cards -->

        <!-- User interface -->


        <!-- Extended components -->




        <!-- Forms & Tables -->

        <!-- Forms -->

        <!-- Tables -->

        <!-- Misc -->



        <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; height: 639px; right: 4px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 365px;"></div></div></ul>
</aside>
<?php /**PATH C:\wamp64\www\attorney\resources\views/panel/admin/layouts/sidebar.blade.php ENDPATH**/ ?>