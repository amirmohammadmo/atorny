<?php $__env->startSection('contend'); ?>
    نظریه کارشناش
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views\panel\user\four.blade.php ENDPATH**/ ?>