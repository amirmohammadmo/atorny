<div>
    <h1>یک فایل از طرف یک کاربر برای شما ارسال شده است</h1>
</div>
<?php /**PATH C:\wamp64\www\attorney\resources\views/panel/admin/email/send_File_From_user.blade.php ENDPATH**/ ?>