<div>
    <h1>یک فایل از طرف وکیل برای شما ارسال شده است</h1>
</div>
<?php /**PATH C:\wamp64\www\attorney\resources\views/panel/user/mail/send_File_From_admin.blade.php ENDPATH**/ ?>