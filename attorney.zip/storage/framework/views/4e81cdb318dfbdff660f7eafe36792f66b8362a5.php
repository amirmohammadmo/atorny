<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert"><?php echo e(session('success')); ?></div>
<?php endif; ?>
<?php if(session('inventory')): ?>
    <div class="alert alert-danger" role="alert"><?php echo e(session('inventory')); ?></div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\attorney\resources\views\panel\admin\layouts\success.blade.php ENDPATH**/ ?>