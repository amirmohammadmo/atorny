<?php $__env->startSection('contend'); ?>
    دیگر مدارک
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views/panel/user/nine.blade.php ENDPATH**/ ?>