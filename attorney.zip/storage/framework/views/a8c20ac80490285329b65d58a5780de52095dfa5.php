
<?php echo $__env->make('panel.admin.layouts.validat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('panel.admin.layouts.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-xxl">
        <div class="card mb-4">
            <div class="card-header d-flex align-items-center justify-content-between">
                <h5 class="mb-0">ارسال مدارک</h5>
                <small class="text-muted float-end"></small>
            </div>
            <div class="card-body">
                <form action="<?php echo e(Route('user.send_protest.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="defaultFormControlInput" class="form-label">نوع مدرک</label>
                        <input type="text" class="form-control" id="defaultFormControlInput"  aria-describedby="defaultFormControlHelp" name="type">
                        <div id="defaultFormControlHelp" class="form-text">
                            نوع مدرک خود را وارد نمایید برای مثال "فیش پرداختی"
                        </div>
                    </div>
                    <input class="form-control" type="file" id="formFile" name="file">
                    <div class="row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">ارسال</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php if($file_users && count($file_users) > 0): ?>
<div class="card">
    <h5 class="card-header">جدول فایل های ارسالی</h5>
    <div class="table-responsive text-nowrap">
        <table class="table">
            <thead>
            <tr>
                <th>نوع مدرک</th>
                <th>عملیات</th>

            </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            <tr>
                <?php $__currentLoopData = $file_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($file_user->type); ?></strong></td>
                <td>
                   <a href="<?php echo e(Route('user.downloadUserFile',$file_user->id)); ?>"> <button type="button" class="btn rounded-pill btn-success">دانلود</button></a>
                   <a href="<?php echo e(Route('user.file_delete',$file_user->id)); ?>"> <button type="button" class="btn rounded-pill btn-danger">حذف</button></a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table><?php else: ?>



            <div class="card">
                <h5 class="card-header">جدول فایل های ارسالی</h5>
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>نوع مدرک</th>
                            <th>عملیات</th>

                        </tr>
                        </thead> <tbody class="table-border-bottom-0"> <td>  موردی یافت نشد</td>   </tbody>

        <?php endif; ?>

    </div>
</div>

</div>
<?php /**PATH C:\wamp64\www\attorney\resources\views/panel/user/layouts/send_document_user.blade.php ENDPATH**/ ?>