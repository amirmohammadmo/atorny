<?php $__env->startSection('contend'); ?>
    <div class="card">
        <h5 class="card-header"></h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>نام کاربر</th>
                        <th>عملیات</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($user->name); ?></strong>
                        </td>



                        <td>
                            <button type="button" class="btn btn-icon btn-outline-primary">
                                <a href="<?php echo e(Route('admin.Documents_users.show',$user->id)); ?>"><span class="bx bxs-file-doc"></span></a>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views/panel/admin/documents_user.blade.php ENDPATH**/ ?>