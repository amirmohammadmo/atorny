<?php if($file && count($file) >0): ?>
    <?php $__currentLoopData = $file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="card accordion-item">
            <h2 class="accordion-header" id="headingOne">
                <button type="button" class="accordion-button collapsed" data-bs-toggle="collapse" data-bs-target="#accordionOne" aria-expanded="false" aria-controls="accordionOne">
                    <?php echo e($fil->category->name); ?>              </button>
            </h2>

            <div id="accordionOne" class="accordion-collapse collapse" data-bs-parent="#accordionExample" style="">
                <div class="accordion-body">

                    <a href="<?php echo e(Route('user.download',$fil->id)); ?>"><button type="button" class="btn btn-success">دانلود</button></a>
                </div>
            </div>
        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?> <div class="alert alert-primary" role="alert">هنوز فایلی برای شما بارگزاری نشده</div><?php endif; ?>
<?php /**PATH C:\wamp64\www\attorney\resources\views/panel/user/layouts/body_page.blade.php ENDPATH**/ ?>