<?php $__env->startSection('contend'); ?>
    دادخواست بدوی و تجدید نظر
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views\panel\user\six.blade.php ENDPATH**/ ?>