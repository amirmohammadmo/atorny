<?php $__env->startSection('contend'); ?>
<?php echo $__env->make('panel.user.layouts.send_document_user',$file_users, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views/panel/user/eighte.blade.php ENDPATH**/ ?>