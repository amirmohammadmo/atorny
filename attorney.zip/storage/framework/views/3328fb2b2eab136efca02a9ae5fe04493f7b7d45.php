<?php $__env->startSection('contend'); ?>


    <div class="card">
        <h5 class="card-header">فایل های ارسال شده از طرف وکیل</h5>
        <h5 class="card-header"></h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>نام ارسال شده</th>
                        <th>عملیات</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $document_send; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document_sends): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($document_sends->category->name); ?></strong>
                            </td>



                            <td>
                                <button type="button" class="btn btn-icon btn-outline-primary">
                                    <a href="<?php echo e(Route('admin.show',$document_sends->id)); ?>"><span class="bx bxs-file-doc"></span></a>
                                </button>
                                <button type="button" class="btn btn-icon btn-outline-primary">
                                    <a href="<?php echo e(Route('admin.Documents_admin.delete',$document_sends->id)); ?>"><span class="bx bxs-message-alt-x"></span></a>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <hr class="my-5">

    <div class="card">
        <h5 class="card-header">فایل های ارسال شده از طرف موکل</h5>
        <h5 class="card-header"></h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>نام ارسال شده</th>
                        <th>عملیات</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $document_reseave; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document_reseaves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($document_reseaves->type); ?></strong>
                            </td>



                            <td>
                                <button type="button" class="btn btn-icon btn-outline-primary">
                                    <a href="<?php echo e(Route('admin.Documents_received.download',$document_reseaves->id)); ?>"><span class="bx bxs-file-doc"></span></a>

                                </button>
                                <button type="button" class="btn btn-icon btn-outline-primary">
                               <a href="<?php echo e(Route('admin.Documents_users.delete',$document_reseaves->id)); ?>"> <span class="bx bxs-message-alt-x"></span></a>
                                    </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\attorney\resources\views/panel/admin/document_show.blade.php ENDPATH**/ ?>