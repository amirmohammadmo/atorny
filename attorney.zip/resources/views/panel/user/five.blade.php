@extends('panel.user.index')
@section('contend')
    @include('panel.user.layouts.body_page',$file)


@endsection
