@if(session('success'))
    <div class="alert alert-success" role="alert">{{session('success')}}</div>
@endif
@if(session('inventory'))
    <div class="alert alert-danger" role="alert">{{session('inventory')}}</div>
@endif
